#pragma once
 void dump_buf(char* ciphertext_32, int lenth);
void sm3(char plaintext[], int* hash_val);
